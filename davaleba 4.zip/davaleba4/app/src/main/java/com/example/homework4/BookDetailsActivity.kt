package com.example.homework4

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BookDetailsActivity : AppCompatActivity() {

    private lateinit var titleTextView: TextView
    private lateinit var authorTextView: TextView
    private lateinit var yearTextView: TextView
    private lateinit var descriptionTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_details)


        titleTextView = findViewById(R.id.titleTextView)
        authorTextView = findViewById(R.id.authorTextView)
        yearTextView = findViewById(R.id.yearTextView)
        descriptionTextView = findViewById(R.id.descriptionTextView)

        // 2. ვიღებთ მონაცემებს Intent-დან
        val title = intent.getStringExtra("title")
        val author = intent.getStringExtra("author")
        val year = intent.getIntExtra("year", 0)
        val description = intent.getStringExtra("description")

        // 3. ვაჩვენებთ მონაცემებს View-ებში
        titleTextView.text = title
        authorTextView.text = author
        yearTextView.text = year.toString()
        descriptionTextView.text = description
    }
}
