package com.example.homework4.SQl

object DBConfig {
    const val version = 1
    const val appDb = "APP_DB"
}