package com.example.homework6

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.homework6.Database.App

class AboutActivity : AppCompatActivity() {

    private lateinit var nameTextView: TextView
    private lateinit var descriptionTextView: TextView
    private var carId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        nameTextView = findViewById(R.id.textView)
        descriptionTextView = findViewById(R.id.textView2)

        carId = intent.getIntExtra("car_id", -1)
        if (carId != -1) {
            val car = App.instance.db.getCarDao().getCarById(carId)
            nameTextView.setText(car.name)
            descriptionTextView.setText(car.description)
        }
    }
}
