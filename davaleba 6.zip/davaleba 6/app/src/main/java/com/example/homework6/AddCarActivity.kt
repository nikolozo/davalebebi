package com.example.homework6

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.homework6.Database.App
import com.example.homework6.Database.Car

class AddCarActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_car)

        val nameEditText = findViewById<EditText>(R.id.editTextText)
        val descriptionEditText = findViewById<EditText>(R.id.editTextText3)
        val addButton = findViewById<Button>(R.id.button)

        addButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val description = descriptionEditText.text.toString()

            if (name.isBlank() || description.isBlank()) {
                Toast.makeText(this, "გთხოვთ შეავსოთ ყველა ველი", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newCar = Car(
                id = 0,
                name = name,
                description = description
            )

            Thread {
                App.instance.db.getCarDao().insertAll(newCar)
                runOnUiThread {
                    Toast.makeText(this, "მანქანა დაემატა!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }.start()
        }
    }
}
