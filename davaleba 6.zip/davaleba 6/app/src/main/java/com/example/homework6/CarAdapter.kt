import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.homework6.Database.Car
import com.example.homework6.R
class CarAdapter(
    private val cars: List<Car>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<CarAdapter.CarViewHolder>() {

    inner class CarViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.textView)
        val descTextView: TextView = itemView.findViewById(R.id.textView2)

        init {
            itemView.setOnClickListener {
                listener.onItemClick(cars[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_car, parent, false)
        return CarViewHolder(view)
    }

    override fun onBindViewHolder(holder: CarViewHolder, position: Int) {
        val car = cars[position]
        holder.titleTextView.text = car.name
        val descriptionPreview = if (car.description.length > 30) {
            car.description.substring(0, 35) + "..."
        } else {
            car.description
        }
        holder.descTextView.text = descriptionPreview
    }

    override fun getItemCount(): Int {
        return cars.size
    }
    interface OnItemClickListener {
        fun onItemClick(car: Car)
    }
}
