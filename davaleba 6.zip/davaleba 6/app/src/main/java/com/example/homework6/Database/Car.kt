package com.example.homework6.Database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "CARS")
data class Car(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ID")
    var id : Int,

    @ColumnInfo(name = "NAME")
    var name : String,


    @ColumnInfo(name = "DESCRIPTION")
    var description: String
)