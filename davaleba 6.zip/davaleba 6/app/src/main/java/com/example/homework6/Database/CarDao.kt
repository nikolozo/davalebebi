package com.example.homework6.Database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface CarDao {
    @Query("select * from CARS")
    fun getAllCars():List<Car>


    @Insert(onConflict = OnConflictStrategy.Companion.REPLACE)
    fun insertAll(vararg cars: Car)

    @Query("delete from CARS")
    fun deleteAll();

    @Update
    fun updateCar(car: Car)

    @Query("SELECT * FROM CARS WHERE ID = :id")
    fun getCarById(id: Int): Car

}