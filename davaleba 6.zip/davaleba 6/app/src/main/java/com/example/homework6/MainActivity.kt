package com.example.homework6

import CarAdapter
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.homework6.Database.App
import com.example.homework6.Database.Car
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var cars: MutableList<Car>
    private lateinit var adapter: CarAdapter

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        cars = App.instance.db.getCarDao().getAllCars().toMutableList()

        adapter = CarAdapter(cars, object : CarAdapter.OnItemClickListener {
            override fun onItemClick(car: Car) {
                val intent = Intent(this@MainActivity, AboutActivity::class.java)
                intent.putExtra("car_id", car.id)
                startActivity(intent)
            }
        })

        recyclerView.adapter = adapter

        val fabAddCar = findViewById<FloatingActionButton>(R.id.fabAddCar)
        fabAddCar.setOnClickListener {
            val intent = Intent(this, AddCarActivity::class.java)
            startActivity(intent)
        }
    }


    override fun onResume() {
        super.onResume()
        cars.clear()
        cars.addAll(App.instance.db.getCarDao().getAllCars())
        adapter.notifyDataSetChanged()
    }
}